<?php
  include 'submit.php';
  if(!isset($_SESSION['username'])) {
      show_msg("请先登录系统!", "login.php");
  }
  
  $person = get_person_info();



?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">
<HTML xmlns="http://www.w3.org/1999/xhtml"><HEAD><TITLE>个人空间－留言板</TITLE>
<META http-equiv=Content-Type content="text/html; charset=gb2312">
<STYLE type=text/css>BODY {
	MARGIN: 0px
}
</STYLE>
<LINK href="css/css.css" type=text/css rel=stylesheet>
<STYLE type=text/css>.STYLE1 {
	FONT-FAMILY: "宋体"
}
</STYLE>

<script type="text/javascript" src="js/jquery-3.7.1.min.js"></script>
<script type="text/javascript">

  $(document).ready(function(){
    $("#old_pw").blur(function(){
        var old_pw = $(this).val();
        $.ajax({
            type: "POST",
            url: "handle_pw.php",
            data: {pw:old_pw,operator:1}, 
            success: function(data){
                  $("#check_res").attr("value",data);
            
            }
        });
    });
    $("#new_pw").blur(function(){
        var new_pw = $(this).val();
        var check_res = $("#check_res").val();
        if(check_res == "原密码正确"){
          $.ajax({
            type : "POST",
            url : "handle_pw.php",
            data :{pw:new_pw,operator:2},
            success : function(data){
                  alert(data);
            }
          });
        }else{
          alert("原密码错误,无法设置新密码！");
        }
    });
  });
</script>



<script type = "text/javascript" src="ckeditor/ckeditor.js"></script>


<META content="MSHTML 6.00.2900.6003" name=GENERATOR>

</HEAD>
<BODY>

<TABLE cellSpacing=0 cellPadding=0 width=760 align=center border=0>
  <TBODY>
  <TR>
    <TD
    style="BORDER-RIGHT: #c0c0c0 1px solid; BORDER-LEFT: #c0c0c0 1px solid; BORDER-BOTTOM: #c0c0c0 1px solid"
    vAlign=top width=140 bgColor=#eeeeee>
      <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
        <TBODY>
        <TR>
          <TD class=left_bg2>当前用户：<A class=link3
            href="person.php">[<?php echo $_SESSION['username']; ?>]</A></TD></TR>
        <TR>
          <TD class=left_bg2><A class=link3
            href="register.php">用户注册</A></TD></TR>
        <TR>
          <TD class=left_bg2><A class=link3
            href="login.php">用户登录</A></TD></TR>
        <TR>
        <TR>
          <TD class=left_bg2><A class=link3
            href="view.php">查看留言</A></TD></TR>
        <TR>
          <TD class=left_bg2><A class=link3
            href="lyb.php">在线留言</A></TD></TR>
          <TR>
          <TD class=left_bg2><A class=link3
            href="logout.php?action=out">退出登录</A></TD></TR>
          </TBODY></TABLE>
      <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
        <TBODY>
        <TR>
          <TD></TD></TR></TBODY></TABLE></TD>
    <TD vAlign=top width=8></TD>
    <TD vAlign=top>
      <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
        <TBODY>
        <TR>
          <TD class=bt>个人空间</TD></TR></TBODY></TABLE>
      <TABLE cellSpacing=0 cellPadding=10 width="100%" border=0>
        <TBODY>
        <TR>
          <TD height=350>
            <TABLE cellSpacing=1 cellPadding=6 width="100%" bgColor=#ff9900
            border=0>
              <TBODY>
              <TR>
                <TD
                bgColor=#fff2e6>您可在此处查看个人的所有相关信息<a href='view_sx.php'>[查看私信]</a></TD></TR></TBODY></TABLE><BR>
            <TABLE borderColor=#111111 cellSpacing=0 cellPadding=4 width="100%"
            bgColor=#ffffff border=0>

            <?php
                echo "<tr><td>用户：".$person['user_name']."</td></tr>";
                echo "<tr><td>积分：".$person['score']."</td></tr>";
                echo "<tr><td>等级：".$person['level']."</td></tr>";
                echo "<tr><td>原密码：<input type='password' id='old_pw'><input type='hidden' id='check_res'></td></tr>";
                echo "<tr><td>新密码：<input type='password' id='new_pw'></td></tr>";
                switch($person['power']){
                    case 0:
                        echo "<tr><td>权限：超级管理员</td></tr>";
                        break;
                    case 1:
                        echo "<tr><td>权限：普通管理员</td></tr>";
                        break;
                    case 2:
                        echo "<tr><td>权限：普通用户</td></tr>";
                        break;
                    case 3:
                        echo "<tr><td>权限：受限用户</td></tr>";
                        break;
                }

            ?>
            
            <tr align="right"><td><a href="#" onclick="javascript:history.back(-1);">[返回上一页]</a></tr></td>

              </TABLE></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE>
</BODY></HTML>
