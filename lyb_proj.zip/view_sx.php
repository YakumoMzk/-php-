<?php
  include 'submit.php';
  include 'pages.class.php';
  if(!isset($_SESSION['username'])) {
      show_msg("请先登录系统!", "login.php");
  }
  
  $sx_info = get_sxs();

  $ly_page = 5;
  // 第一步：先初始化$curr_page（关键！避免未定义或为0）
  $curr_page = isset($_GET['page']) && is_numeric($_GET['page']) && $_GET['page'] > 0 ? intval($_GET['page']) : 1;
  
  // 总页数计算
  $sql = "select * from sx_info where send_to= '".$_SESSION['username']."'";
  $res = mysqli_query($conn, $sql);
  $ly_nums = mysqli_num_rows($res);
  $page_nums = ceil($ly_nums / $ly_page);
  
  // 第二步：防止当前页超过总页数，同时确保$curr_page最小为1
  if ($curr_page > $page_nums) {
      $curr_page = $page_nums;
  }
  if ($curr_page < 1) {
      $curr_page = 1;
  }
  
  // 第三步：计算偏移量并强制转为整数（避免负数、非数字，修复SQL语法错误）
  $offset = intval(($curr_page - 1) * $ly_page);
  // 获取当前页面的所有私信（用$offset拼接SQL，确保LIMIT后无负数）
  $sql = "select * from sx_info where send_to='".$_SESSION['username']."' limit ".$offset.",".$ly_page;
  $res = mysqli_query($conn, $sql);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">
<HTML xmlns="http://www.w3.org/1999/xhtml"><HEAD><TITLE>查看私信－留言板</TITLE>
<META http-equiv=Content-Type content="text/html; charset=gb2312">
<STYLE type=text/css>BODY {
	MARGIN: 0px
}
</STYLE>
<LINK href="css/css.css" type=text/css rel=stylesheet>
<STYLE type=text/css>.STYLE1 {
	FONT-FAMILY: "宋体"
}
</STYLE>

<script type = "text/javascript" src="js/jquery-3.7.1.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    $("td>span").click(function(){
      
      var sx_id = $(this).attr("id");
      $.ajax({
        type:"get",
        url:"get_sx_cont.php",
        data:{id:sx_id},
        success:function(data){
          alert(data);
        }
      });
    })
  });
</script><!-- 闭合script标签 -->
<script type = "text/javascript" src="ckeditor/ckeditor.js"></script>

<META content="MSHTML 6.00.2900.6003" name=GENERATOR>

</HEAD>
<BODY>

<TABLE cellSpacing=0 cellPadding=0 width=760 align=center border=0>
  <TBODY>
  <TR>
    <TD
    style="BORDER-RIGHT: #c0c0c0 1px solid; BORDER-LEFT: #c0c0c0 1px solid; BORDER-BOTTOM: #c0c0c0 1px solid"
    vAlign=top width=140 bgColor=#eeeeee>
      <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
        <TBODY>
        <TR>
          <TD class=left_bg2>当前用户：<A class=link3
            href="person.php">[<?php echo $_SESSION['username']; ?>]</A></TD></TR>
        <TR>
          <TD class=left_bg2><A class=link3
            href="register.php">用户注册</A></TD></TR>
        <TR>
          <TD class=left_bg2><A class=link3
            href="login.php">用户登录</A></TD></TR>
        <TR>
        <TR>
          <TD class=left_bg2><A class=link3
            href="view.php">查看留言</A></TD></TR>
        <TR>
          <TD class=left_bg2><A class=link3
            href="lyb.php">在线留言</A></TD></TR>
          <TR>
          <TD class=left_bg2><A class=link3
            href="logout.php?action=out">退出登录</A></TD></TR>
          </TBODY></TABLE>
      <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
        <TBODY>
        <TR>
          <TD></TD></TR></TBODY></TABLE></TD>
    <TD vAlign=top width=8></TD>
    <TD vAlign=top>
      <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
        <TBODY>
        <TR>
          <TD class=bt>查看私信</TD></TR></TBODY></TABLE>
      <TABLE cellSpacing=0 cellPadding=10 width="100%" border=0>
        <TBODY>
        <TR>
          <TD height=350>
            <TABLE cellSpacing=1 cellPadding=6 width="100%" bgColor=#ff9900
            border=0>
              <TBODY>
              <TR>
                <TD
                bgColor=#fff2e6>您可在此处分页查看所有的私信信息,点击标题查看</TD></TR></TBODY></TABLE><BR>
            <TABLE borderColor=#111111 cellSpacing=0 cellPadding=4 width="100%"
            bgColor=#ffffff border=0>
            <tr><th>序号</th><th>标题</th><th>发送人</th><th>发送时间</th></tr>

            <?php
                $no = 1 + ($curr_page - 1) * $ly_page;
                
                while($row = mysqli_fetch_assoc($res)){
                    echo "<tr>";
                    echo "<td align=center>".$no++."</td>";
                    echo "<td align=center class='get_cont'><span id ='".$row['id']."'>$row[title]</span></td>";
                    echo "<td align=center><a href='sx.php?sendto=".$row['send_from']."'>$row[send_from]</a></td>";
                    echo "<td align=center>$row[send_time]</td>";
                    echo "</tr>";
                }
            ?>

              </TABLE>
              <TABLE cellSpacing=0 cellPadding=10 width="100%" border=0>
                <TBODY>
                <TR>
                  <TD align=center>
                    <?php
                    $page = new Pages($ly_page, $ly_nums, $curr_page, 5, "view_sx.php?page=", 2);
                    ?>
                  </TD>
                </TR>
                </TBODY>
              </TABLE>
              </TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE>
</BODY></HTML>