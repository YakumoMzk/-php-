<?php 
  session_start();

  $pw = $_POST['pw'];
  $operator = $_POST['operator'];
  $conn = mysqli_connect("localhost","root","","lyb");
  
  if($operator == '1'){
      //验证旧密码
      $sql = "select * from user_info where user_name= '".$_SESSION['username']."' and password='$pw'";
      $res = mysqli_query($conn,$sql);
      if(mysqli_num_rows($res) > 0){
          echo "原密码正确";
      }else{
          echo "原密码错误";
      }
  }else if($operator == '2'){
      //修改新密码
      $sql = "update user_info set password='$pw' where user_name= '".$_SESSION['username']."'";
      $res = mysqli_query($conn,$sql);
      if($res){
          echo "密码修改成功";
      }else{
          echo "密码修改失败";
      }
    
  }




?>