<?php
  session_start();
  if($_GET['action'] == 'out') {
    session_unset();
    session_destroy();
    include 'submit.php';
    show_msg("您已成功退出登录!", "login.php");
  }
?>