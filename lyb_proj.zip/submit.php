<?php
session_start();
$conn = mysqli_connect("localhost", "root", "", "lyb"); 

date_default_timezone_set('Asia/Shanghai');
function show_msg($msg,$url) {
    $win_str = "<html xmlns='http://www.w3.org/1999/xhtml'>
    <head>
    <meta http-equiv='Content-Type' content='text/html; charset=gb2312'>
    <meta http-equiv='refresh' content='3;URL=".$url."'>
    <title>提示信息</title>
    </head>

    <body>
    <table width='200'  border='1' align='center' cellpadding='0' cellspacing='0' bordercolor='#FF0000'>
      <tr>
        <td align='center'><strong>提示信息</strong></td>
          <table width='100%' border='0' cellpadding='5' cellspacing='0'>
      </tr>
      <tr>
        <td align='center'><p style='font-size:14px'>".$msg."</p>
        <p>3秒钟后跳转到登录页面......</p></td>
      </tr>
    </table>
    </body>
    </html>";
    echo $win_str;
    exit();
}

//登录函数
function login($username, $pw) {
    global $conn;
    $sql = "SELECT * FROM user_info WHERE user_name='" . $username . "' AND password='" . $pw . "'";

    $res = mysqli_query($conn, $sql);

    if(mysqli_num_rows($res) > 0) {
      $_SESSION['username'] = $username;
      $_session['pw'] = $pw;
      show_msg($username.",欢迎发表留言!", "lyb.php");
    } else {
      show_msg("用户名或密码错误，请重新登录!", "login.php");
    }
}


//注册函数（示例，需根据实际需求完善）
function register($username, $pw, $pw2) {
  global $conn;
  $sql = "insert into user_info (user_name, password,score,level,power) values ('".$username."','".$pw."',0,'新兵',2)";
  $res = mysqli_query($conn, $sql);
  if($res) {
    show_msg("注册成功，请登录!", "login.php");
  }else{
    show_msg("注册失败，请重试!", "register.php");  
  }
  
}


//留言发布函数
function ly_publish($title, $type, $content) {
  global $conn;
  
  $sql = "insert into ly_info (title,ly_type,content,author,ly_time) values('$title','$type','$content','".$_SESSION['username']."','".date('Y-m-d H:i:s')."')";
  
  
  $res = mysqli_query($conn, $sql);

  if($res) {
    //show_msg("留言发布成功!", "view.php");
    update_sc(10,"留言");

}else{
    show_msg("留言发布失败，请重试!", "lyb.php");  
  }
}


//积分升级函数
function update_sc($sc,$type)
{

  global $conn;
  //加分
  $sql = "update user_info set score=score+".$sc." where user_name='" . $_SESSION['username'] . "'";
  $res = mysqli_query($conn,$sql);
  
  if($res){

    //检查是否升级
    //获取当前用户积分,等级
    $sql = "select * from user_info where user_name='" . $_SESSION['username'] . "'";
    $res = mysqli_query($conn,$sql);
    $curr_user = mysqli_fetch_assoc($res);
    $curr_user_level = $curr_user['level'];
    $curr_user_score = $curr_user['score'];
    //查询当前用户等级对应level表中的位置
    $sql = "select * from user_level where level_name='".$curr_user_level."'";
    $res = mysqli_query($conn,$sql);
    $cuur_level = mysqli_fetch_assoc($res);
    $curr_level_id = $cuur_level['id'];
    //查询下一级别
    $sql = "select * from user_level where id>".$curr_level_id." limit 1";
    $res = mysqli_query($conn,$sql);

    //判断是否存在下一级别
    if(mysqli_num_rows($res)>0){
      //进行升级
        $nexct_level = mysqli_fetch_assoc($res);
        if($curr_user_score>=$nexct_level['level_score']){
          //升级
          $sql = "update user_info set level='".$nexct_level['level_name']."' where user_name='" . $_SESSION['username'] . "'";
          $res = mysqli_query($conn,$sql);
          if($res){
            show_msg("".$type."成功,获得".$sc."积分奖励,恭喜您升级到".$nexct_level['level_name']."级!", "view.php");
          }else{
            show_msg("".$type."发布成功!您获得".$sc."积分奖励!但升级失败了", "view.php");
          }
        }else{
          show_msg("".$type."发布成功!您获得".$sc."积分奖励!", "view.php");
        }
    }else{
      //当大哥了
        show_msg("最高级了,不给经验了!", "view.php");
    }


  }else{
    show_msg("积分更新失败，请重试!", "lyb.php");
  }
}


//获取留言列表函数
function get_lys(){
  global $conn;
  $sql = "select * from ly_info";
  $res = mysqli_query($conn, $sql);
  return $res;
}


//获取个人信息函数
function get_person_info(){
  global $conn;
  $sql = "select * from user_info where user_name='" . $_SESSION['username'] . "'";
  $res = mysqli_query($conn, $sql);
  $person = mysqli_fetch_assoc($res);
  return $person;
}


//获取留言详细信息函数
function get_ly_info($id){
  global $conn;
  $sql = "select * from ly_info where id=$id";
  $res = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($res);
  return $row;
}

//发表回复函数
function rpl_publish($info){

  global $conn;
  
  $sql = "insert into rpl_info values(null,'".$info['content']."','".$_SESSION['username']."','".date('Y-m-d H:i:s')."','".$info['ly_id']."')";
  $res = mysqli_query($conn, $sql);
  if($res) {
    show_msg("回复发表成功!增加5积分!", "disp.php?id=".$info['ly_id']);
    update_sc(5,"回复");
  }else{
    show_msg("回复发表失败，请重试!", "disp.php?id=".$info['ly_id']);  
  }
}


//获取所有回复函数
function get_all_rpl($id){
  global $conn;
  $sql = "select * from rpl_info where ly_id=$id";
  $res = mysqli_query($conn, $sql);
  $info = array();
  while($row = mysqli_fetch_assoc($res)){
    array_push($info,$row);
  }
  return $info;
}

//发送私信函数
function sx_publish($title, $cont,$sendto) {
  global $conn;
  
  $sql = "insert into sx_info(send_to,send_from,title,content,send_time) values('$sendto','".$_SESSION['username']."','$title','$cont','".date('Y-m-d H:i:s')."')";
  
  $res = mysqli_query($conn, $sql);

  if($res) {
    show_msg("私信发送成功!", "view.php");
  }else{
    show_msg("私信发送失败，请重试!","view.php");
  }
}

//获取私信列表函数
function get_sxs(){
  global $conn;
  $sql = "select * from sx_info";
  $res = mysqli_query($conn, $sql);
  return $res;
}

//获取用户权限
function get_user_power(){
  global $conn;
  $sql = "select power from user_info where user_name='".$_SESSION['username']."'";
  $res = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($res);
  return $row['power'];
}

?>