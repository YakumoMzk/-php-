<?php

  $user = $_POST['username'];
  $link = mysqli_connect("localhost", "root", "","lyb");
  $sql = "select * from user_info where user_name='".$user."'";
  $res = mysqli_query($link, $sql);

  if(mysqli_num_rows($res) > 0) {
    echo "用户名已存在，请更换用户名";
  } else {
    echo "用户名可以使用";
  }
?>