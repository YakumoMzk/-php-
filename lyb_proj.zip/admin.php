<?php
  include 'submit.php';
  include 'pages.class.php';
  if(!isset($_SESSION['username'])) {
      show_msg("请先登录系统!", "login.php");
  }
  if(get_user_power()>1){
      show_msg("您没有权限访问该页面!", "lyb.php");
  }

  $user_info = get_lys();
  $per_user = 4; //每页显示用户数
  //获取所有用户数
  $total_user = mysqli_num_rows($user_info);
  //获取当前要显示的页面数
  if (isset($_GET['page'])){
      $curr_page = $_GET['page'];
  } else {
      $curr_page = 1;
  }
  //获取总用户数
  $total_page = ceil($total_user / $per_user);
  //查询当前页面的留言信息
  $sql = "select * from user_info where power>".get_user_power()." limit ".($curr_page-1)*$per_user.",".$per_user;
  $res = mysqli_query($conn, $sql);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">
<HTML xmlns="http://www.w3.org/1999/xhtml"><HEAD><TITLE>用户管理－留言板</TITLE>
<META http-equiv=Content-Type content="text/html; charset=gb2312">
<STYLE type=text/css>BODY {
	MARGIN: 0px
}
</STYLE>
<LINK href="css/css.css" type=text/css rel=stylesheet>
<STYLE type=text/css>.STYLE1 {
	FONT-FAMILY: "宋体"
}
</STYLE>

<script type = "text/javascript" src="ckeditor/ckeditor.js"></script>


<META content="MSHTML 6.00.2900.6003" name=GENERATOR>

</HEAD>
<BODY>

<TABLE cellSpacing=0 cellPadding=0 width=760 align=center border=0>
  <TBODY>
  <TR>
    <TD
    style="BORDER-RIGHT: #c0c0c0 1px solid; BORDER-LEFT: #c0c0c0 1px solid; BORDER-BOTTOM: #c0c0c0 1px solid"
    vAlign=top width=140 bgColor=#eeeeee>
      <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
        <TBODY>
        <TR>
          <TD class=left_bg2>当前用户：<A class=link3
            href="person.php">[<?php echo $_SESSION['username']; ?>]</A></TD></TR>
        <TR>
          <TD class=left_bg2><A class=link3
            href="admin.php">用户管理</A></TD></TR>
        <TR>
          <TD class=left_bg2><A class=link3
            href="ly.php">留言管理</A></TD></TR>
        <TR>
            <TD class=left_bg2><A class=link3
            href="reply.php">回复管理</A></TD></TR>
        <TR>
          <TD class=left_bg2><A class=link3
            href="vote.php">投票管理</A></TD></TR>
          <TR>
          <TD class=left_bg2><A class=link3
            href="logout.php?action=out">退出登录</A></TD></TR>
          </TBODY></TABLE>
      <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
        <TBODY>
        <TR>
          <TD></TD></TR></TBODY></TABLE></TD>
    <TD vAlign=top width=8></TD>
    <TD vAlign=top>
      <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
        <TBODY>
        <TR>
          <TD class=bt>用户管理</TD></TR></TBODY></TABLE>
      <TABLE cellSpacing=0 cellPadding=10 width="100%" border=0>
        <TBODY>
        <TR>
          <TD height=350>
            <TABLE cellSpacing=1 cellPadding=6 width="100%" bgColor=#ff9900
            border=0>
              <TBODY>
              <TR>
                <TD
                bgColor=#fff2e6>您可在此处分页管理所有的用户信息</TD></TR></TBODY></TABLE><BR>
            <TABLE borderColor=#111111 cellSpacing=0 cellPadding=4 width="100%"
            bgColor=#ffffff border=0>
            <tr><th>序号</th><th>用户名</th><th>权限</th><th>管理操作</th></tr>

            <?php
                $no = 1;
                while($row = mysqli_fetch_assoc($res)){
                    echo "<tr>";
                    echo "<td align=center>".$no++."</td>";
                    echo "<td>$row[user_name]</td>";
                    echo "<td><select name='power' id='".$row['id']."'>";
                    if(get_user_power()==0){
                      switch($row['power']){
                        case 1:
                          echo "<option selected value=1>普通管理员</option>";
                          echo "<option value=2>普通用户</option>";
                          echo "<option value=3>受限用户</option>";
                        break;
                        case 2:
                          echo "<option value=1>普通管理员</option>";
                          echo "<option selected value=2>普通用户</option>";
                          echo "<option value=3>受限用户</option>";
                        break;
                        case 3:
                          echo "<option value=1>普通管理员</option>";
                          echo "<option value=2>普通用户</option>";
                          echo "<option selected value=3>受限用户</option>";
                        break;
                      }
                      
                    }else{
                      switch($row['power']){
                        case 2:
                          echo "<option selected value=2>普通用户</option>";
                          echo "<option value=2>普通用户</option>";
                        break;
                        case 3:
                          echo "<option value=2>普通用户</option>";
                          echo "<option selected value=3>受限用户</option>";
                        break;
                      }
                    }
                    echo "</select>";
                    echo "</td>";
                    echo "<td align=center><button id='".$row['id']."'>删除</button></td>";
                    echo "</tr>";
                }
                echo "<tr><td colspan='4' align='center'>";

                //分页类实现导航链接
                $page = new Pages($per_user, $total_user, $curr_page, 5, "admin.php?page=",2);

                echo "</td></tr>";
            ?>

              </TABLE></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE>
</BODY></HTML>
