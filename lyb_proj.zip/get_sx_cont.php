<?php

$id = $_GET['id'];
$conn = mysqli_connect("localhost", "root", "", "lyb");
mysqli_query($conn, "set names utf8");
$sql = "select * from sx_info where id = $id";
$res = mysqli_query($conn, $sql); 
$row = mysqli_fetch_assoc($res);
echo strip_tags($row['content']);


?>