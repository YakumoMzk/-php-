<?php
include 'submit.php';
// 注意：注册页面应调用注册逻辑，而非登录函数，这里先保留你的代码结构，后续需补充注册功能
if(isset($_POST['submit'])) {
    register($_POST['username'], $_POST['password'], $_POST['password2']);
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">
<HTML xmlns="http://www.w3.org/1999/xhtml"><HEAD><TITLE>用户注册－留言板</TITLE>
<META http-equiv=Content-Type content="text/html; charset=gb2312">
<STYLE type=text/css>BODY {
	MARGIN: 0px
}
</STYLE>
<LINK href="css/css.css" type=text/css rel=stylesheet>
<STYLE type=text/css>.STYLE1 {
	FONT-FAMILY: "宋体"
}
</STYLE>
<script type="text/javascript">
function check(){
  if(myform.username.value==""){
    alert("用户名不能为空!");
    return false;
  }
  // 修正：JavaScript中逻辑或用 || 而非 or
  if(myform.password.value=="" || myform.password2.value==""){
    alert("密码不能为空!");
    return false;
  }
  if(myform.password.value!=myform.password2.value){
    alert("两次输入的密码不一致!");
    return false;
  }
  if(document.getElementById("check_name").innerHTML!="用户名可以使用"){
    alert("用户名已被占用，请更换!");
    return false;
  }
  
  return true; // 验证通过返回true
}
</script> <!-- 闭合script标签 -->

<script type="text/javascript" src="js/jquery-3.7.1.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    $("#username").blur(function(){
      var user = $(this).val();
      $.ajax({
        type:"post",
        url:"check_name.php",
        data:{username:user},
        success:function(data){
          $("#check_name").html(data);
        }
      })
    });
  });
</script>



<META content="MSHTML 6.00.2900.6003" name=GENERATOR></HEAD>
<BODY>

<TABLE cellSpacing=0 cellPadding=0 width=760 align=center border=0>
  <TBODY>
  <TR>
    <TD
    style="BORDER-RIGHT: #c0c0c0 1px solid; BORDER-LEFT: #c0c0c0 1px solid; BORDER-BOTTOM: #c0c0c0 1px solid"
    vAlign=top width=140 bgColor=#eeeeee>
      <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
        <TBODY>
        <TR>
          <TD class=left_bg2><A class=link3 href="register.php">用户注册</A></TD></TR>
        <TR>
          <TD class=left_bg2><A class=link3 href="login.php">用户登录</A></TD></TR>
        <TR>
        <TR>
          <TD class=left_bg2><A class=link3 href="view.php">查看留言</A></TD></TR>
        <TR>
          <TD class=left_bg2><A class=link3 href="lyb.php">在线留言</A></TD></TR>
        <TR>
          <TD class=left_bg2><A class=link3
            href="logout.php?action=out">退出登录</A></TD></TR>
        
        </TBODY></TABLE>
      <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
        <TBODY>
        <TR>
          <TD></TD></TR></TBODY></TABLE></TD>
    <TD vAlign=top width=8></TD>
    <TD vAlign=top>
      <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
        <TBODY>
        <TR>
          <TD class=bt>用户注册</TD></TR></TBODY></TABLE> <!-- 标题从“用户登录”改为“用户注册” -->
      <TABLE cellSpacing=0 cellPadding=10 width="100%" border=0>
        <TBODY>
        <TR>
          <TD height=350>
            <TABLE cellSpacing=1 cellPadding=6 width="100%" bgColor=#ff9900 border=0>
              <TBODY>
              <TR>
                <TD bgColor=#fff2e6>请在此注册您的各项信息,然后登录发表你的留言,我们会及时处理您的留言,并通过电子邮件形式发送给您</TD></TR></TBODY></TABLE><BR>
            <TABLE borderColor=#111111 cellSpacing=0 cellPadding=4 width="100%" bgColor=#ffffff border=0>
              <!-- 表单添加 onsubmit 事件，触发验证函数 -->
              <FORM id=myform name=myform action="" method=post onsubmit="return check()">
              <DIV></DIV>
              <TBODY>
              <TR>
                <TD vAlign=bottom noWrap colSpan=2></TD></TR>
              <TR>
                <TD vAlign=bottom width=55>用户：</TD>
                <TD vAlign=bottom><INPUT id=username size=20 name=username> *<span style="color:red" id="check_name"></span> </TD></TR>
                <TD vAlign=bottom width=55>密码：</TD>
                <TD vAlign=bottom><INPUT id=password type="password" size=20 name=password> * </TD></TR>
                <TD vAlign=bottom width=65>确认密码：</TD>
                <TD vAlign=bottom><INPUT id=password2 type="password" size=20 name=password2> * </TD></TR>
              <TR>
                <TD colSpan="2">
  				<input type="submit" name="submit" value="注册"/>
  				<input type="reset" name="reset" value="重置"/>
                </TD></TR></TBODY>
              <DIV></DIV></FORM></TABLE></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE>
</BODY></HTML>