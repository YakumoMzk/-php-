document.write("<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">");
document.write("<tr>");
document.write("<td id=\"top\">")
document.writeln("<table width=\"760\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">");
document.writeln("    <tr> ");
document.writeln("      <td height=\"25\" bgcolor=\"F3F3F3\"><iframe scrolling=\"No\" id=\"logonFrame\" frameborder=\"0\" src=\"\/inc\/loginplug.aspx\" width=\"100%\" height=\"25\" marginheight=\"0\" marginwidth=\"0\" align=\"top\" hspace=\"0\" vspace=\"0\"><\/iframe><\/td>");
document.writeln("      <td width=\"200\" valign=\"bottom\"><table border=\"0\" align=\"right\" cellpadding=\"0\" cellspacing=\"0\">");
document.writeln("          <tr> ");
document.writeln("            <td width=\"16\" valign=\"top\"><a href=\"\/\"><font color=\"6D6D6D\"><img src=\"\/images\/ico\/top01.gif\" border=\"0\" \/><\/font><\/a><\/td>");
document.writeln("            <td width=\"60\" height=\"22\"><a onclick=\"this.style.behavior='url(#default#homepage)';this.setHomePage('http://www.sewworld.com');\" href=\"#\"><font color=\"6D6D6D\">��Ϊ��ҳ<\/font><\/a><\/td>");
document.writeln("            <td width=\"16\" valign=\"top\"><a href=\"\/\"><font color=\"6D6D6D\"><img src=\"\/images\/ico\/top02.gif\" width=\"16\" height=\"15\" border=\"0\" \/><\/font><\/a><\/td>");
document.writeln("            <td width=\"35\"><a href=\"/aboutus/wydz.html\" target=\"_blank\"><font color=\"6D6D6D\">����<\/font><\/a><\/td>");
document.writeln("            <td width=\"45\"><a href=\"#\"><u><font color=\"6D6D6D\">����վ<\/font><\/u><\/a><\/td>");
document.writeln("          <\/tr>");
document.writeln("        <\/table><\/td>");
document.writeln("    <\/tr>");
document.writeln("  <\/table>");
document.write("</td>");
document.write("</tr></table>");
document.write("<table width=\"760\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">");
document.write("<tr>");
document.write("<td height=\"75\"><a href=\"http://www.sewworld.com\"><img src=\"http://www.sewworld.com/images/logo_new.gif\" width=\"180\" height=\"50\" border=\"0\" /></a></td>");
document.write("<td height=\"75\"  align=\"right\"><font class=\"font1\" color=\"#666666\">��ѯ����:+86-571-87176768</font></td>");
document.write("<td  width=\"115\" height=\"75\"  align=\"right\"><a href=\"http://tel.sewworld.com/recall.aspx?pid=5FD6F6BC1733633D\" title=\"�����ѻغ�ͨ��\" target=\"_blank\" class=\"Join\" onfocus=\"this.blur()\" onmousedown=\"return hcclick('?hctracelog=news6in1mic')\"><img src=\"images/tel.gif\" border=\"0\" /></td>");
document.write("</tr></table>");

