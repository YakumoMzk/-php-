﻿<?php
  include 'submit.php';
  if(!isset($_SESSION['username'])) {
      show_msg("请先登录系统!", "login.php");
  }
  if(isset($_POST['submit'])) {
      ly_publish($_POST['title'], $_POST['type'], $_POST['content']);
  }
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">
<HTML xmlns="http://www.w3.org/1999/xhtml"><HEAD><TITLE>在线留言－留言板</TITLE>
<META http-equiv=Content-Type content="text/html; charset=gb2312">
<STYLE type=text/css>BODY {
	MARGIN: 0px
}
</STYLE>
<LINK href="css/css.css" type=text/css rel=stylesheet>
<STYLE type=text/css>.STYLE1 {
	FONT-FAMILY: "宋体"
}
</STYLE>

<script type = "text/javascript" src="ckeditor/ckeditor.js"></script>

<script type="text/javascript">
function check(){
  for (instance in CKEDITOR. instances){
    ckeditor.instances[instance].updateElement();
  }

  if(myform.title.value==""){
    alert("主题不能为空!");
    return false;
  }
  
  if(myform.content.value==""){
    alert("回复内容不能为空!");
    return false;
  }
  return true; // 验证通过返回true
}
</script> <!-- 闭合script标签 -->

<META content="MSHTML 6.00.2900.6003" name=GENERATOR>

</HEAD>
<BODY>

<TABLE cellSpacing=0 cellPadding=0 width=760 align=center border=0>
  <TBODY>
  <TR>
    <TD
    style="BORDER-RIGHT: #c0c0c0 1px solid; BORDER-LEFT: #c0c0c0 1px solid; BORDER-BOTTOM: #c0c0c0 1px solid"
    vAlign=top width=140 bgColor=#eeeeee>
      <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
        <TBODY>
        <TR>
          <TD class=left_bg2>当前用户：<A class=link3
            href="person.php">[<?php echo $_SESSION['username']; ?>]</A></TD></TR>
        <TR>
        <?php 
          if(get_user_power()<2){
        ?>
          <TD class=left_bg2><A class=link3
            href="admin.php">后台管理</A></TD></TR>
        <?php } ?>
        <TR>
          <TD class=left_bg2><A class=link3
            href="register.php">用户注册</A></TD></TR>
        <TR>
          <TD class=left_bg2><A class=link3
            href="login.php">用户登录</A></TD></TR>
        <TR>
        <TR>
          <TD class=left_bg2><A class=link3
            href="view.php">查看留言</A></TD></TR>
        <TR>
          <TD class=left_bg2><A class=link3
            href="lyb.php">在线留言</A></TD></TR>
          <TR>
          <TD class=left_bg2><A class=link3
            href="logout.php?action=out">退出登录</A></TD></TR>
          </TBODY></TABLE>
      <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
        <TBODY>
        <TR>
          <TD></TD></TR></TBODY></TABLE></TD>
    <TD vAlign=top width=8></TD>
    <TD vAlign=top>
      <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
        <TBODY>
        <TR>
          <TD class=bt>用户反馈</TD></TR></TBODY></TABLE>
      <TABLE cellSpacing=0 cellPadding=10 width="100%" border=0>
        <TBODY>
        <TR>
          <TD height=350>
            <TABLE cellSpacing=1 cellPadding=6 width="100%" bgColor=#ff9900
            border=0>
              <TBODY>
              <TR>
                <TD
                bgColor=#fff2e6>感谢您提出的需求、意见和建议，我们会认真及时处理您的留言，并通过电子邮件给您回复。</TD></TR></TBODY></TABLE><BR>
            <TABLE borderColor=#111111 cellSpacing=0 cellPadding=4 width="100%"
            bgColor=#ffffff border=0>
              <FORM id=myform name=myform action="" method=post onsubmit="return check()">
              <DIV></DIV>
              <TBODY>
              <TR>
                <TD vAlign=bottom noWrap colSpan=2></TD></TR>
              <TR>
                <TD vAlign=bottom width=55>主题：</TD>
                <TD vAlign=bottom><INPUT id=title size=40 name=title> * </TD></TR>
              <TR bgColor=#f7f7f7>
                <TD vAlign=bottom>类型：</TD>
                <TD vAlign=bottom noWrap height=26><SPAN id=Type><INPUT
                  id=Type_0 type=radio CHECKED value=1 name=type> <LABEL
                  for=Type_0>求助</LABEL> <INPUT id=Type_1 type=radio value=2
                  name=type> <LABEL for=Type_1>建议</LABEL> <INPUT id=Type_2
                  type=radio value=3 name=type> <LABEL for=Type_2>投诉</LABEL>
                  <INPUT id=Type_3 type=radio value=4 name=type> <LABEL
                  for=Type_3>表扬</LABEL> <INPUT id=Type_4 type=radio value=5
                  name=type> <LABEL for=Type_4>业务联系</LABEL> </SPAN></TD></TR>
              <TR>
                <TD vAlign=top rowSpan=2>内容：</TD>
                <TD><TEXTAREA id=content name=content rows=10 cols=50></TEXTAREA>
                  *
                <script type="text/javascript">
                    var editor = CKEDITOR.replace( 'content' );
                </script>
              </TD></TR>
              <TR>
                <TD>
  				<input type="submit" name="submit" value="留言"/>
  				<input type="reset" name="reset" value="重置"/>
                </TD></TR></TBODY>
              <DIV></DIV></FORM></TABLE></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE>
</BODY></HTML>
